<?php
$db_host = "localhost";
$db_user = "netplane_college";
$db_password = "collegedb5762";
$db_name = "netplane_collegeDatabase";
/*$db_host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "collegedatabase";*/
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);
if ($conn->connect_error) {
    die("Connection Failed");
}
