<?php
define("TITLE", "Delete Uploaded Files");
define("PAGE", "deleteFile.php");
require("db_connection.php");
session_start();
if (!isset($_SESSION['is_login'])) {
    echo "<script> location.href='adminLogin.php'; </script>";
}
if (isset($_REQUEST['delete'])) {
    $sqlDelete = "DELETE FROM notifications WHERE id = ?";
    $result = $conn->prepare($sqlDelete);
    $result->bind_param("i", $delId);
    $delId = $_REQUEST['delete_id'];
    if ($result->execute()) {
        echo '<span class="alert alert-success"> "Successfully Deleted"</span>';
    } else {
        echo '<span class="alert alert-danger"> "Cannot Deleted"</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Bootstrap Css-->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <!--fontAwesome-->
    <link rel="stylesheet" href="assets/fontawesome-free-5.11.2-web/css/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <title><?php echo TITLE ?></title>
    <style>
        table thead th {
            font-size: 22px;
        }

        table tbody td {
            font-size: 20px;
            color: brown;
            font-weight: bold;
        }

        table tbody tr td a i {
            font-size: 25px;
            margin-left: 20px;

        }

        table tbody tr td a {
            color: brown;
            text-transform: capitalize;
        }

        table tbody tr td a:hover {
            text-decoration: none;
            color: orangered;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-sm-2 bg-light sidebar py-5 d-print-none">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'Upload File') {
                                                    echo 'active';
                                                } ?>" href="uploadFile.php">
                                <i class="fas fa-file-upload"></i>
                                File Upload <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled <?php if (PAGE == 'Upload Images') {
                                                            echo 'active';
                                                        } ?>" href="">
                                <i class="fas fa-upload"></i>
                                Image Upload
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'deleteFile.php') {
                                                            echo 'active';
                                                        } ?>" href="deleteFile.php">
                                <i class="fas fa-trash-alt"></i>
                                Delete Uploaded Docs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'changePassword.php') {
                                                            echo 'active';
                                                        } ?>" href="changePassword.php">
                                <i class="fas fa-key"></i>
                                Change Password
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="col-sm-9 col-md-10">
                <h1 class="text-primary text-center"></h1>
                <div class="table-responsive">
                    <table class="table table-striped text-center">
                        <thead class="bg-danger text-white">
                            <tr>
                                <th>Documents</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                                        $sqlDisplay = "SELECT * FROM notifications";
                                                        $result = $conn->prepare($sqlDisplay);
                                                        $result->bind_result($id, $detail, $doc, $date);
                                                        $result->execute();
                                                        while ($result->fetch()) {
                            ?>
                                <tr>

                                    <td>
                                        <a href="<?php echo $doc; ?>">
                                            <?php echo $detail; ?>
                                        </a>
                                    </td>
                                    <td><?php echo $date; ?></td>
                                    <td><a class="text-success" href="<?php echo $doc; ?>">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a class="text-primary" download href="<?php echo $doc; ?>">
                                            <i class="fas fa-cloud-download-alt"></i>
                                        </a>

                                        <form action="" method="POST"><input type="hidden" name="delete_id" value="<?php echo $id; ?>"><button name="delete" class="fas fa-trash text-danger btn btn-lg"></button></form>
                                    </td>';
                                    </td>
                                </tr>
                            <?php
                                                                                                                }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>




    <!--JavaScripts-->
    <script src="assets/bootstrap/bootstrap.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
</body>

</html>