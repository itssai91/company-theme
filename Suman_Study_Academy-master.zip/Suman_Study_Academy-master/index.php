<?php
define("TITLE", "Documents By Suman Study Academy");
require("db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Bootstrap Css-->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <!--fontAwesome-->
    <link rel="stylesheet" href="assets/fontawesome-free-5.11.2-web/css/all.min.css">
    <title><?php echo TITLE ?></title>
    <style>
        table thead th {
            font-size: 22px;
        }

        table tbody td {
            font-size: 20px;
            color: brown;
            font-weight: bold;
        }

        table tbody tr td a i {
            font-size: 25px;
            margin-left: 20px;

        }

        table tbody tr td a {
            color: brown;
            text-transform: capitalize;
        }

        table tbody tr td a:hover {
            text-decoration: none;
            color: orangered;
        }
    </style>
</head>

<body>

    <div class="container">
        <a href="adminLogin.php" class="btn btn-lg btn-info">Admin Login
        </a>
        <h1 class="text-primary text-center">SUMAN STUDY ACADEMY</h1>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="bg-danger text-white">
                    <tr>
                        <th>Documents</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sqlDisplay = "SELECT detail, doc, date FROM notifications";
                    $result = $conn->prepare($sqlDisplay);
                    $result->bind_result($detail, $doc, $date);
                    $result->execute();
                    while ($result->fetch()) {
                    ?>
                        <tr>

                            <td>
                                <a href="<?php echo $doc; ?>">
                                    <?php echo $detail; ?>
                                </a>
                            </td>
                            <td><?php echo $date; ?></td>
                            <td><a class="text-success" href="<?php echo $doc; ?>">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a class="text-primary" download href="<?php echo $doc; ?>">
                                    <i class="fas fa-cloud-download-alt"></i>
                                </a>
                            </td>
                        </tr>
                    <?php
                                                                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>



    <!--JavaScripts-->
    <script src="assets/bootstrap/bootstrap.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
</body>

</html>