<?php
define("TITLE", "Admin Section Page");
define("PAGE", "Upload File");
require("db_connection.php");
session_start();
if (isset($_SESSION['is_login'])) {
} else {
    echo "<script> location.href='adminLogin.php'; </script>";
}
if (isset($_POST['submit'])) {
    $details = $_POST['detail'];
    $date = $_POST['date'];
    $files = $_FILES['file'];
    //File Details
    $fileName = $files['name'];
    $fileType = $files['type'];
    $fileTempLoc = $files['tmp_name'];

    $fileLocation = 'upload/' . $fileName;
    if (move_uploaded_file($fileTempLoc, $fileLocation)) {
        $sqlInsert = "INSERT INTO notifications (detail, doc, date) VALUES ('$details', '$fileLocation', '$date')";
        if (mysqli_query($conn, $sqlInsert)) {
            echo '<span class="alert alert-success"> "Successfully Uploaded"</span>';
        } else {
            echo '<span class="alert alert-success"> "Uploading Failed"</span>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Bootstrap Css-->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <!--fontAwesome-->
    <link rel="stylesheet" href="assets/fontawesome-free-5.11.2-web/css/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <title><?php echo TITLE ?></title>
</head>

<body>
    <div class="container-fluid mb-5 ">
        <div class="row">
            <nav class="col-sm-2 bg-light sidebar py-5 d-print-none">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'Upload File') {
                                                    echo 'active';
                                                } ?>" href="uploadFile.php">
                                <i class="fas fa-file-upload"></i>
                                File Upload <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled <?php if (PAGE == 'Upload Images') {
                                                            echo 'active';
                                                        } ?>" href="">
                                <i class="fas fa-upload"></i>
                                Image Upload
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'deleteFile.php') {
                                                            echo 'active';
                                                        } ?>" href="deleteFile.php">
                                <i class="fas fa-trash-alt"></i>
                                Delete Uploaded Docs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'changePassword.php') {
                                                            echo 'active';
                                                        } ?>" href="changePassword.php">
                                <i class="fas fa-key"></i>
                                Change Password
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="col-sm-9 col-md-10">
                <h1 class="text-danger text-center">Welcome To File Uploading Section</h1>
                <div class="panel panel-primary">
                    <div class="panel-heading"><b>Upload Documents</b></div>
                    <div class="panel-body">
                        <form method="post" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="text">Enter Details:</label>
                                <input type="text" class="form-control" id="detail" name="detail">
                            </div>
                            <div class="form-group">
                                <label for="file">Choose Only PDF File</label>
                                <input type="file" name="file" class="form-control" id="file" accept=".pdf, .png, .jpg, .jpeg, .doc, .ppt">
                            </div>
                            <div class="form-group">
                                <label for="date">Enter Details:</label>
                                <input type="date" class="form-control" id="date" name="date">
                            </div>
                            <button type="submit" name="submit" class="btn btn-danger btn-lg">Submit</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!--Row End-->
    </div>



    <!--JavaScripts-->
    <script src="assets/bootstrap/bootstrap.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
</body>

</html>