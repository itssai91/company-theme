<?php
define("TITLE", "Change Password");
define("PAGE", "changePassword.php");
require("db_connection.php");
session_start();
if (isset($_SESSION['is_login'])) {
    $a_user = $_SESSION['aUser'];
} else {
    echo "<script> location.href='adminLogin.php'; </script>";
}
if (isset($_REQUEST['passupdate'])) {
    if (($_REQUEST['uPassword'] == "")) {
        // msg displayed if required field missing
        $passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
    } else {
        $sql = "SELECT * FROM admin WHERE userName='$a_user'";
        $result = $conn->query($sql);
        if ($result->num_rows == 1) {
            $uPass = $_REQUEST['uPassword'];
            $sql = "UPDATE admin SET password = '$uPass' WHERE userName = '$a_user'";
            if ($conn->query($sql) == TRUE) {
                // below msg display on form submit success
                $passmsg = '<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert"> Updated Successfully </div>';
            } else {
                // below msg display on form submit failed
                $passmsg = '<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert"> Unable to Update </div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Bootstrap Css-->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <!--fontAwesome-->
    <link rel="stylesheet" href="assets/fontawesome-free-5.11.2-web/css/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <title><?php echo TITLE ?></title>
</head>

<body>
    <div class="container-fluid mb-5 ">
        <div class="row">
            <nav class="col-sm-2 bg-light sidebar py-5 d-print-none">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'Upload File') {
                                                    echo 'active';
                                                } ?>" href="uploadFile.php">
                                <i class="fas fa-file-upload"></i>
                                File Upload <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled <?php if (PAGE == 'Upload Images') {
                                                            echo 'active';
                                                        } ?>" href="">
                                <i class="fas fa-upload"></i>
                                Image Upload
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'deleteFile.php') {
                                                            echo 'active';
                                                        } ?>" href="deleteFile.php">
                                <i class="fas fa-trash-alt"></i>
                                Delete Uploaded Docs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php if (PAGE == 'changePassword.php') {
                                                            echo 'active';
                                                        } ?>" href="changePassword.php">
                                <i class="fas fa-key"></i>
                                Change Password
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i>
                                Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="col-sm-9 col-md-10">
                <div class="row">
                    <div class="col-sm-6">
                        <form class="mt-5 mx-5" method="POST">
                            <div class="form-group">
                                <label for="inputEmail">Email</label>
                                <input type="email" class="form-control" id="inputEmail" value=" <?php echo $a_user ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="inputnewpassword">New Password</label>
                                <input type="password" class="form-control" id="inputnewpassword" placeholder="New Password" name="uPassword">
                            </div>
                            <button type="submit" class="btn btn-danger mr-4 mt-4" name="passupdate">Update</button>
                            <button type="reset" class="btn btn-secondary mt-4">Reset</button>
                            <?php if (isset($passmsg)) {
                                                                                                        echo $passmsg;
                                                                                                    } ?>
                        </form>

                    </div>

                </div>
            </div </div> <!--Row End-->
        </div>



        <!--JavaScripts-->
        <script src="assets/bootstrap/bootstrap.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
</body>

</html>